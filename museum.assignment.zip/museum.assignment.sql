drop database if exists museum;

create database museum;

use museum;

-- Creating a  Table name met
create table met(
ID INT PRIMARY KEY,
Department varchar(100),
Category varchar(100),
Title varchar(100),
Artist varchar(100),
Date varchar(100),
Medium varchar(100),
Country varchar(100));

-- inserting Data into table

select * from met;

-- Select the top 10 rows in the met table 
select * from met
limit 10;

 
-- How many pieces are in the American Metropolitan Art collection

select Department,COUNT(*) as "American Metro Art"
from met
where Department = 'American Metropolitan Art';


-- Count the number of pieces where the category includes ‘celery’
select count(Category) as "num.of category includes celery" from met
where Category like "%celery%";

-- Find the title and medium of the oldest piece(s) in the collection

select Title, Medium,Date  from met;

-- Find the top 10 countries with the most pieces in the collection 
select Country,count(*) from met
group by Country
order by Country desc
limit 10;

-- Find the categories which have more than 100 pieces
select Category,count(*) from met
group by Category
 having count(*) >100;

-- Count the number of pieces where the medium contains ‘gold’ or ‘silver’ and sort in descending order
select case
  when Medium like '%gold%' then'Gold'
  when Medium like'%Silver%' then 'Silver'
  else 'Other'
  end as 'GOLD/SILVER',
  count(Medium) as 'Gold/Silver_Count'
from met
where 'GOLD/SILVER' IS NOT NULL
GROUP BY 1
ORDER BY 2 desc;



 